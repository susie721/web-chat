"use strict";
exports.id = 363;
exports.ids = [363];
exports.modules = {

/***/ 6363:
/***/ ((module) => {

module.exports = JSON.parse('{"Index":{"title":"您好!","description":"Das ist die Startseite."},"LocaleSwitcher":{"switchLocale":"Zu {locale, select, de {Deutsch} en {Englisch} other {Unbekannt}} wechseln"},"PageLayout":{"pageTitle":"AI智能生活工具"},"Header":{"language":{"zh":"中文","hk":"繁体"}}}');

/***/ })

};
;